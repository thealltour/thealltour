/**

 * HTML 컨텍스트 보존형 수집 — UI prep + lazy 이미지 활성화 + 정제 HTML 캡처.

 * DOM 파싱 없음; AI가 HTML 시퀀스로 일정·이미지를 매핑합니다.

 */

(function (global) {

  const TRASH_SELECTORS = "script, style, iframe, noscript, svg, header, footer, nav";

  // body 클론 후 제거할 노이즈 (GNB·푸터·최근본·후기필터 등). 본문 전체는 유지한다.
  const BODY_CAPTURE_BLACKLIST_SELECTORS = [
    "header",
    "nav",
    "footer",
    ".footer",
    "#header",
    "#footer",
    ".gnb_wrap",
    ".quick_menu",
    ".recent_prod",
    ".app_banner",
    ".review_filter_wrap",
    "[class*='recommend']",
    "[class*='related']",
    "[class*='review_list'] select",
    "[class*='review_list'] button",
    "[class*='coupon']",
    "[class*='gnb']",
    "[class*='Gnb']",
    "[class*='GNB']",
    "[class*='recent_view']",
    "[class*='recently']",
    "[class*='Recent']",
    "[class*='prod_recent']",
    "[class*='recent_prod']",
    "[class*='footer_wrap']",
    "[class*='Footer']",
    "[class*='banner_area']",
    "[class*='Banner']",
    ".ly_recent",
    ".recent_prd",
    "[class*='review']",
    "[id*='review']",
    ".review_wrap",
    ".review_area",
    ".related_items",
    ".recommend_items",
    ".recommend_prod",
    "select",
    "option",
    "script",
    "style",
    "noscript",
    "iframe",
  ].join(", ");

  const HTML_BLACKLIST_SELECTORS = BODY_CAPTURE_BLACKLIST_SELECTORS;

  const JUNK_URL_RE = /logo|icon|banner|spinner|arrow|badge|avatar|favicon/i;



  function sleep(ms) {

    return new Promise((resolve) => setTimeout(resolve, ms));

  }



  // cloneNode 결과(detached)에서는 innerText가 ""인 경우가 많다(렌더 트리 없음).
  // ?? 는 ""를 유효값으로 취급해 textContent 폴백이 막히므로 || 를 쓴다.
  function elementText(el) {
    return (el.innerText || el.textContent || "").replace(/\s+/g, " ").trim();
  }

  const NOISE_CUT_KEYWORDS = [
    "구매고객 후기",
    "동반자 유형",
    "함께 많이 본 상품",
    "명의 하나투어 후기",
  ];

  function isNoiseMarkerText(text) {
    if (!text) return false;
    if (text === "상품명") return true;
    return NOISE_CUT_KEYWORDS.some((kw) => text.includes(kw));
  }

  function climbNoiseContainer(el, clone, maxDepth) {
    let target = el;
    const depth = maxDepth ?? 5;
    for (let i = 0; i < depth; i += 1) {
      const parent = target.parentElement;
      if (!parent || parent === clone) break;
      const tag = parent.tagName?.toLowerCase?.() ?? "";
      if (tag === "body" || tag === "html") break;
      target = parent;
    }
    return target;
  }

  function removeNodeAndFollowingSiblings(node) {
    if (!node || !node.parentElement) {
      node?.remove?.();
      return;
    }
    let cur = node;
    while (cur) {
      const next = cur.nextElementSibling;
      cur.remove();
      cur = next;
    }
  }

  /** 노이즈 앵커부터 main/clone 직계 자식을 절단(이후 형제까지 제거). */
  function truncateNoiseTailFromClone(clone) {
    const root = clone.querySelector("main") ?? clone;
    const candidates = root.querySelectorAll(
      "button, a, strong, h2, h3, h4, h5, span, p, em, label, legend",
    );
    let firstMarker = null;
    for (const el of candidates) {
      if (isNoiseMarkerText(elementText(el))) {
        firstMarker = el;
        break;
      }
    }
    if (!firstMarker) return;

    let cut = firstMarker;
    while (cut.parentElement && cut.parentElement !== root && cut.parentElement !== clone) {
      cut = cut.parentElement;
    }
    if (cut === root || cut === clone) {
      cut = climbNoiseContainer(firstMarker, clone, 5);
    }
    if (!cut || cut === root || cut === clone) return;
    removeNodeAndFollowingSiblings(cut);
  }

  function removeNoiseByParentClimb(clone) {
    const hits = [];
    for (const el of clone.querySelectorAll("button, a, strong, h2, h3, h4, span, p, em, label")) {
      if (!el.isConnected) continue;
      if (isNoiseMarkerText(elementText(el))) hits.push(el);
    }
    for (const el of hits) {
      if (!el.isConnected) continue;
      const target = climbNoiseContainer(el, clone, 5);
      if (target && target !== clone && target.parentElement) target.remove();
    }
  }



  function isJunkImageUrl(url) {

    if (!url || url.startsWith("data:")) return true;

    return JUNK_URL_RE.test(url);

  }



  function pickBestSrcFromSrcset(srcset, baseUrl) {

    if (!srcset?.trim()) return null;

    const parts = srcset.split(",").map((p) => p.trim()).filter(Boolean);

    let best = null;

    let bestW = -1;

    for (const part of parts) {

      const m = part.match(/^(\S+)\s+(\d+)w$/);

      if (m) {

        const w = parseInt(m[2], 10);

        if (w > bestW) {

          bestW = w;

          best = m[1];

        }

      } else if (!best) {

        best = part.split(/\s+/)[0];

      }

    }

    if (!best) return null;

    try {

      return new URL(best, baseUrl).href;

    } catch {

      return best.startsWith("http") ? best : null;

    }

  }



  function resolveImageUrl(img, baseUrl) {

    const attrs = [

      img.getAttribute("data-src"),

      img.getAttribute("data-original"),

      img.getAttribute("lazy-src"),

      img.getAttribute("data-lazy-src"),

      img.getAttribute("data-lazy"),

      img.currentSrc,

      img.src,

    ];

    for (const raw of attrs) {

      if (!raw?.trim() || raw.startsWith("data:")) continue;

      try {

        const abs = new URL(raw.trim(), baseUrl).href;

        if (!isJunkImageUrl(abs)) return abs;

      } catch {

        if (raw.startsWith("http") && !isJunkImageUrl(raw)) return raw.trim();

      }

    }

    const srcset =

      img.getAttribute("data-srcset") ?? img.getAttribute("srcset");

    const fromSet = pickBestSrcFromSrcset(srcset, baseUrl);

    if (fromSet && !isJunkImageUrl(fromSet)) return fromSet;

    return null;

  }



  function activateLazyLoadedImages(root) {

    root.querySelectorAll("img").forEach((img) => {

      const real = resolveImageUrl(img, global.location?.href ?? "");

      if (real) img.setAttribute("src", real);

    });

    root.querySelectorAll("source[srcset], source[data-srcset]").forEach((source) => {

      const srcset = source.getAttribute("data-srcset") ?? source.getAttribute("srcset");

      const best = pickBestSrcFromSrcset(srcset, global.location?.href ?? "");

      if (best) source.setAttribute("srcset", best);

    });

  }



  function findTabBarRoot(doc) {
    const ui = global.HanatourItineraryUiPrep;
    if (ui?.findProductTabScope) {
      const scope = ui.findProductTabScope(doc);
      if (scope) {
        if (scope.getAttribute?.("role") === "tablist") return scope;
        const inner = scope.querySelector?.('[role="tablist"]');
        if (inner && (!ui.isSiteChrome?.(inner) || /여행\s*일정|상품\s*안내/.test(ui.elementText?.(inner) ?? inner.textContent ?? ""))) {
          return inner;
        }
        if (scope !== doc) return scope;
      }
    }
    const root = ui?.findProductContentRoot?.(doc) ?? doc.querySelector("main");
    if (!root) return null;
    const byText = [...root.querySelectorAll('[role="tab"], button, a, [role="button"]')].find((el) =>
      /여행\s*일정|상품\s*안내|호텔\s*&\s*관광지|선택관광/.test((el.textContent ?? "").replace(/\s+/g, " ")),
    );
    return byText?.closest('[role="tablist"]') ?? byText?.parentElement ?? root;
  }

  function clickIfSafe(el) {
    const ui = global.HanatourItineraryUiPrep;
    if (ui?.safeClick) return ui.safeClick(el);
    el.click();
    return true;
  }

  function clickTabByText(doc, patterns, exactPatterns) {
    const root = findTabBarRoot(doc);
    if (!root) return false;
    const candidates = root.querySelectorAll('[role="tab"], button, a[href="#"], a[role="button"]');

    let fallback = null;

    for (const el of candidates) {
      const text = elementText(el);
      if (!text) continue;

      for (const exact of exactPatterns ?? []) {
        if (text === exact || new RegExp(`^${exact}$`, "i").test(text)) {
          if (clickIfSafe(el)) return true;
        }
      }

      for (const pat of patterns) {
        if (pat.test(text)) {
          if (clickIfSafe(el)) return true;
        }
      }

      if (!fallback && patterns.some((p) => p.test(text))) fallback = el;
    }

    if (fallback) {
      return clickIfSafe(fallback);
    }

    return false;
  }

  function clickMainItineraryTab(doc) {
    return clickTabByText(
      doc,
      [/^여행\s*일정$/i, /여행일정/, /상세\s*일정/, /일정\s*표/],
      ["여행일정", "여행 일정", "상세일정", "상세 일정", "일정표"],
    );
  }



  async function prepareSellingPointsView(doc) {

    clickTabByText(

      doc,

      [/상품\s*안내/, /핵심\s*포인트/, /상품안내/, /상품\s*설명/, /상품\s*정보/],

      ["상품안내", "상품 안내", "상품설명", "상품정보"],

    );

    await sleep(600);

  }



  function clickExpandAllItinerary(doc) {
    const ui = global.HanatourItineraryUiPrep;
    const scope =
      ui?.findItineraryTabPanel?.(doc) ??
      ui?.findProductTabScope?.(doc) ??
      ui?.findProductContentRoot?.(doc);
    if (!scope) return false;
    const groups = [
      scope.querySelectorAll("button, [role='tab'], [role='button']"),
      scope.querySelectorAll("a, span"),
    ];
    for (const candidates of groups) {
      for (const el of candidates) {
        if ((el.childElementCount ?? 0) > 6) continue;
        const text = (el.textContent ?? "").trim().slice(0, 40);
        if (!/일정\s*전체\s*펼침|전체\s*펼침/i.test(text)) continue;
        if (clickIfSafe(el)) return true;
      }
    }
    return false;
  }

  async function expandAccordionsIn(root, maxClicks) {
    const toggles = [];
    root.querySelectorAll('[aria-expanded="false"]').forEach((el) => toggles.push(el));
    let clicks = 0;
    for (const btn of toggles) {
      if (clicks >= (maxClicks ?? 60)) break;
      if (btn.getAttribute("aria-expanded") === "true") continue;
      if (!clickIfSafe(btn)) continue;
      clicks++;
      await sleep(120);
    }
    return clicks;
  }



  function clickMoreButtons(root, maxClicks) {
    if (!root) return 0;
    let clicks = 0;
    const els = root.querySelectorAll("button, a, [role='button'], span");
    for (const el of els) {
      if (clicks >= (maxClicks ?? 24)) break;
      if ((el.childElementCount ?? 0) > 6) continue;
      const text = (el.textContent ?? "").trim().slice(0, 24);
      if (!/더보기|더\s*보기|펼쳐보기/i.test(text)) continue;
      if (clickIfSafe(el)) clicks += 1;
    }
    return clicks;
  }

  async function prepareItineraryView(doc) {
    const ui = global.HanatourItineraryUiPrep;
    const mainWait = ui?.MAIN_TAB_WAIT_MS ?? 800;
    const expandWait = ui?.EXPAND_ALL_WAIT_MS ?? 700;

    clickMainItineraryTab(doc);
    await sleep(Math.max(mainWait, 600));

    const itineraryPanel = ui?.findItineraryTabPanel?.(doc) ?? findHtmlCaptureRoot(doc);
    if (ui?.clickExpandAllItineraryInScope && itineraryPanel) {
      ui.clickExpandAllItineraryInScope(itineraryPanel);
    } else {
      clickExpandAllItinerary(doc);
    }
    await sleep(Math.max(expandWait, 600));

    clickMoreButtons(itineraryPanel ?? doc.body);
    if (itineraryPanel) {
      await expandAccordionsIn(itineraryPanel);
    }
    await sleep(600);

    if (itineraryPanel && ui?.waitForPanelStable) {
      await ui.waitForPanelStable(itineraryPanel);
    }
  }



  async function scrollToLoadLazyContent(doc) {

    const win = doc.defaultView ?? global;

    const body = doc.body ?? doc.documentElement;

    if (!win || !body) return;

    const step = Math.max(win.innerHeight || 600, 400);

    const maxY = Math.max(body.scrollHeight, doc.documentElement?.scrollHeight ?? 0);

    const startY = win.scrollY ?? 0;

    for (let y = 0; y <= maxY; y += step) {

      win.scrollTo(0, y);

      await sleep(150);

    }

    win.scrollTo(0, startY);

    await sleep(200);

  }



  function buildBodyHtmlCaptureRoot(doc) {
    return doc.body ?? doc.documentElement ?? null;
  }



  function buildCombinedHtmlCaptureRoot(doc) {
    return buildBodyHtmlCaptureRoot(doc);
  }



  function findHtmlCaptureRoot(doc) {
    return buildBodyHtmlCaptureRoot(doc);
  }



  function removeBlacklistedFromClone(clone) {
    clone.querySelectorAll(BODY_CAPTURE_BLACKLIST_SELECTORS).forEach((el) => el.remove());

    // 노이즈 시작점부터 하단 형제(형제 포함). 클래스명에 의존하지 않음.
    truncateNoiseTailFromClone(clone);
    removeNoiseByParentClimb(clone);

    clone.querySelectorAll("section, aside, div, ul").forEach((el) => {
      if (!el.isConnected) return;
      const text = elementText(el).slice(0, 80);
      if (/^최근\s*본\s*상품/.test(text)) el.remove();
      if (/함께\s*많이\s*본\s*상품/.test(text)) el.remove();
      if (/구매\s*고객\s*후기/.test(text)) el.remove();
      if (/동반자\s*유형/.test(text)) el.remove();
      if (/다른\s*상품\s*보기/.test(text)) el.remove();
      if (/앱\s*설치|쿠폰\s*팩|쿠폰팩/.test(text)) el.remove();
    });

    // 타 상품 드롭다운 잔해: [출발확정] 목록 통째 삭제
    clone.querySelectorAll("li").forEach((li) => {
      if (!li.isConnected) return;
      if (elementText(li).includes("[출발확정]")) li.remove();
    });

    clone.querySelectorAll("button").forEach((btn) => {
      if (!btn.isConnected) return;
      const btnText = elementText(btn);
      if (/\[출발확정\]/.test(btnText) || (/출발확정/.test(btnText) && btnText.length > 24)) {
        const parentLi = btn.closest("li");
        if (parentLi) parentLi.remove();
        else btn.remove();
      }
    });
  }



  function minifyHtmlForAi(html) {

    if (!html) return "";

    return html

      .replace(/<!--[\s\S]*?-->/g, "")

      .replace(/\sclass="[^"]*"/gi, "")

      .replace(/\sstyle="[^"]*"/gi, "")

      .replace(/\sdata-[a-z0-9_-]+="[^"]*"/gi, "")

      .replace(/\saria-[a-z0-9_-]+="[^"]*"/gi, "")

      .replace(/\srole="[^"]*"/gi, "")

      .replace(/<img([^>]*?)>/gi, (_m, attrs) => {

        const src = attrs.match(/\ssrc="([^"]+)"/i)?.[1];

        const alt = attrs.match(/\salt="([^"]+)"/i)?.[1];

        if (!src) return "";

        return alt ? `<img src="${src}" alt="${alt}">` : `<img src="${src}">`;

      })

      .replace(/>\s+</g, "><")

      .replace(/\s{2,}/g, " ")

      .trim();

  }



  function minifyHtmlClone(clone) {

    removeBlacklistedFromClone(clone);

    clone.querySelectorAll(TRASH_SELECTORS).forEach((el) => el.remove());

    activateLazyLoadedImages(clone);

    clone.querySelectorAll("*").forEach((el) => {

      const tag = el.tagName.toLowerCase();

      const kept = [];

      if (tag === "img") {

        const src = el.getAttribute("src");

        if (src) kept.push(["src", src]);

        const alt = el.getAttribute("alt");

        if (alt) kept.push(["alt", alt]);

      }

      while (el.attributes.length > 0) {

        el.removeAttribute(el.attributes[0].name);

      }

      for (const [name, value] of kept) {

        el.setAttribute(name, value);

      }

    });

    return minifyHtmlForAi(clone.innerHTML);

  }



  function stripInstallmentMetaLines(text) {
    return text
      .split(/\n/)
      .filter((line) => {
        if (/무이자\s*할부|할부\s*예상가|카드사별\s*무이자/.test(line)) return false;
        if (/월\s*[\d,]+원/.test(line) && /할부|무이자|예상가/.test(line)) return false;
        if (/^\s*월\s*[\d,]+원/.test(line)) return false;
        return true;
      })
      .join("\n");
  }

  // 하나투어는 가격/할부 정보가 있는 예약 사이드바(.prod_detail_side)가 <main> 밖에
  // 위치해 buildPageTextForMeta가 이를 놓치는 경우가 있다. 이 경우 AI가 성인 1인
  // 총액을 보지 못해 본문의 다른 숫자를 가격으로 오인할 수 있으므로 별도로 찾아 붙인다.
  function findBookingPriceRoot(doc) {
    const bySelector = doc.querySelector(
      ".prod_detail_side, [class*='price_area'], [class*='PriceArea'], [class*='priceArea']",
    );
    if (bySelector) return bySelector;

    const candidates = doc.querySelectorAll("aside, [class*='side'], [class*='sticky'], section, div");
    for (const el of candidates) {
      if ((el.childElementCount ?? 0) > 40) continue;
      const text = el.textContent ?? "";
      if (text.length > 4000 || text.length < 10) continue;
      if (/성인\s*1인/.test(text) && /\d{1,3}(,\d{3})+\s*원|₩\s*[\d,]+/.test(text)) return el;
    }
    return null;
  }

  function buildPageTextForMeta(doc, maxChars) {
    const limit = maxChars ?? 18000;
    const root = doc.querySelector("main") ?? doc.body;
    const raw = (root?.innerText ?? "").replace(/\n{3,}/g, "\n\n").trim();
    let text = stripInstallmentMetaLines(raw);

    const priceRoot = findBookingPriceRoot(doc);
    if (priceRoot && !(root?.contains(priceRoot))) {
      const priceRaw = (priceRoot.innerText ?? "").replace(/\n{3,}/g, "\n\n").trim();
      const priceText = stripInstallmentMetaLines(priceRaw);
      if (priceText) text = `${text}\n\n[가격 정보]\n${priceText}`;
    }

    return text.length > limit ? `${text.slice(0, limit)}\n…(truncated)` : text;
  }



  function appendMetaText(base, extra, maxChars) {

    const limit = maxChars ?? 18000;

    if (!extra?.trim()) return base;

    const combined = `${base}\n\n[상품안내·핵심포인트 영역]\n${extra.trim()}`;

    return combined.length > limit ? `${combined.slice(0, limit)}\n…(truncated)` : combined;

  }



  function stripSiteSuffixFromDocumentTitle(raw) {

    if (!raw?.trim()) return "";

    return raw

      .trim()

      .replace(/\s*[-|·]\s*(하나투어|HANATOUR|모두투어|MODETOUR).*$/i, "")

      .trim();

  }



  function pickLongestTitleCandidate(candidates) {

    const cleaned = candidates.map((c) => c?.trim()).filter(Boolean);

    if (cleaned.length === 0) return undefined;

    return cleaned.sort((a, b) => b.length - a.length)[0];

  }



  function extractSourceProductTitle(doc) {

    const ogTitle = doc.querySelector('meta[property="og:title"]')?.getAttribute("content");

    const h1 = doc.querySelector("main h1")?.innerText ?? doc.querySelector("h1")?.innerText;

    const docTitle = stripSiteSuffixFromDocumentTitle(doc.title);

    return pickLongestTitleCandidate([ogTitle, h1, docTitle]);

  }



  function normalizeHashtagToken(raw) {

    return raw.trim().replace(/^#+/, "").trim();

  }



  function collectHashtagTokensFromText(text, push) {

    if (!text?.trim()) return;

    const matches = text.match(/#[^\s#]+/g);

    if (matches) {

      for (const match of matches) {

        const token = normalizeHashtagToken(match);

        if (token) push(token);

      }

    }

  }



  function findHashtagSectionRoot(doc) {

    const candidates = doc.querySelectorAll("h1, h2, h3, h4, h5, h6, p, label, button, strong, [class*='hash'], [class*='Hash']");

    for (const el of candidates) {

      if ((el.childElementCount ?? 0) > 8) continue;

      const text = (el.textContent ?? "").trim().slice(0, 80);

      if (!text) continue;

      if (/AI\s*해시태그/i.test(text) || (text.includes("해시태그") && /AI/i.test(text))) {

        return el.closest("section, article, div") ?? el.parentElement ?? el;

      }

      if (text === "해시태그" || text.endsWith("해시태그")) {

        const container = el.closest("section, article, div") ?? el.parentElement;

        if (container && /AI/i.test(elementText(container).slice(0, 80))) {

          return container;

        }

      }

    }

    return null;

  }



  function extractAiSeoHashtags(doc) {

    const seen = new Set();

    const out = [];

    const push = (token) => {

      const normalized = normalizeHashtagToken(token);

      if (!normalized || seen.has(normalized)) return;

      seen.add(normalized);

      out.push(normalized);

    };



    const sectionRoot = findHashtagSectionRoot(doc);

    if (sectionRoot) {

      collectHashtagTokensFromText(sectionRoot.innerText ?? "", push);

      sectionRoot.querySelectorAll("span, a, button, li, p, div").forEach((el) => {

        const text = elementText(el);

        if (/^#[\w가-힣]+/.test(text)) collectHashtagTokensFromText(text, push);

      });

    }



    if (out.length === 0) {

      const main = doc.querySelector("main") ?? doc.body;

      if (main) {

        main.querySelectorAll("span, a, button, li, p").forEach((el) => {

          const text = elementText(el);

          if (/^#[\w가-힣]{2,}/.test(text)) collectHashtagTokensFromText(text, push);

        });

      }

    }



    return out;

  }



  function sanitizeHtmlClone(clone) {

    return minifyHtmlClone(clone);

  }



  function buildCleanHtmlStructure(doc) {

    const root = buildBodyHtmlCaptureRoot(doc);

    if (!root) return "";

    const clone = root.cloneNode(true);

    return sanitizeHtmlClone(clone);

  }



  function isInsideItineraryPanel(el) {

    let node = el;

    while (node) {

      if (node.getAttribute?.("role") === "tabpanel") {

        const text = elementText(node);

        if (/일차/.test(text)) return true;

      }

      node = node.parentElement;

    }

    return false;

  }



  function findHeroGalleryRoot(doc) {
    const main = doc.querySelector("main") ?? doc.body;
    if (!main) return null;
    const ui = global.HanatourItineraryUiPrep;

    function scoreGallery(el) {
      if (!el) return -1;
      if (isInsideItineraryPanel(el)) return -1;
      if (ui?.isSiteChrome?.(el) && !ui?.isProductUiClick?.(el)) return -1;
      const slides = el.querySelectorAll(".swiper-slide, [class*='swiper-slide'], img");
      let imgs = 0;
      el.querySelectorAll("img").forEach(() => {
        imgs += 1;
      });
      const rect = el.getBoundingClientRect?.();
      const area = rect ? Math.max(0, rect.width) * Math.max(0, rect.height) : 0;
      return slides.length * 10 + imgs * 5 + Math.min(area / 20000, 20);
    }

    const swipers = [...main.querySelectorAll(".swiper, [class*='swiper-container']")].filter((el) => {
      const cls = typeof el.className === "string" ? el.className : "";
      return !/swiper-slide|swiper-wrapper|swiper-button|swiper-pagination|swiper-scrollbar/i.test(cls);
    });
    let best = null;
    let bestScore = 0;
    for (const el of swipers) {
      const s = scoreGallery(el);
      if (s > bestScore) {
        bestScore = s;
        best = el;
      }
    }
    if (best && bestScore > 0) return best;

    const galleries = [...main.querySelectorAll("[class*='gallery']")];
    best = null;
    bestScore = 0;
    for (const el of galleries) {
      const s = scoreGallery(el);
      if (s > bestScore) {
        bestScore = s;
        best = el;
      }
    }
    if (best && bestScore > 0) return best;

    return null;
  }



  function collectOgImageUrl(doc) {

    const baseUrl = doc.defaultView?.location?.href ?? global.location?.href ?? "";

    const selectors = [

      'meta[property="og:image"]',

      'meta[name="og:image"]',

      'meta[property="twitter:image"]',

    ];

    for (const sel of selectors) {

      const el = doc.querySelector(sel);

      const content = el?.getAttribute("content")?.trim();

      if (!content || isJunkImageUrl(content)) continue;

      try {

        return new URL(content, baseUrl).href;

      } catch {

        if (content.startsWith("http")) return content;

      }

    }

    return null;

  }



  function collectSlideImages(slide, baseUrl, push) {

    activateLazyLoadedImages(slide);

    slide.querySelectorAll("img").forEach((img) => {

      const url = resolveImageUrl(img, baseUrl);

      if (url) push(url);

    });

  }



  function findGallerySwiperInstance(heroRoot) {

    const swiperEl = heroRoot.querySelector?.(".swiper, [class*='swiper'], [class*='Swiper']");

    if (!swiperEl) return null;

    try {

      return swiperEl.swiper ?? swiperEl.__swiper__ ?? null;

    } catch {

      return null;

    }

  }



  function findGalleryNavButton(heroRoot) {
    const byClass = heroRoot.querySelector?.(
      ".swiper-button-next, [class*='swiper-button-next'], [class*='slide-next']",
    );
    if (byClass) return byClass;
    const candidates = heroRoot.querySelectorAll("button, a, [role='button']");
    for (const el of candidates) {
      const cls = (el.className && typeof el.className === "string" ? el.className : "") || "";
      const aria = (el.getAttribute?.("aria-label") ?? "").toLowerCase();
      if (
        /swiper-button-next/i.test(cls) ||
        /next|다음|slide-next|arrow-right/i.test(cls) ||
        /next|다음/i.test(aria)
      ) {
        return el;
      }
    }
    return null;
  }



  function isGalleryNavDisabled(el) {

    if (!el) return true;

    return (

      el.classList?.contains("swiper-button-disabled") ||

      el.getAttribute("aria-disabled") === "true" ||

      el.hasAttribute("disabled")

    );

  }



  /**

   * 가상/지연 렌더링 슬라이더는 활성 슬라이드만 DOM에 존재할 수 있음 —

   * 다음 버튼을 반복 클릭해 슬라이드를 순회하며 새 이미지가 더 없을 때까지 수집.

   * 시간이 걸려도 완전한 수집을 우선함(요청사항).

   */

  async function advanceGalleryAndCollect(heroRoot, baseUrl, push, out) {

    const MAX_CLICKS = 25;

    const MAX_STAGNANT = 4;

    let stagnant = 0;



    for (let i = 0; i < MAX_CLICKS; i += 1) {

      const before = out.length;

      const swiper = findGallerySwiperInstance(heroRoot);

      let advanced = false;

      if (swiper && typeof swiper.slideNext === "function") {

        try {

          swiper.slideNext();

          advanced = true;

        } catch {

          advanced = false;

        }

      }

      if (!advanced) {

        const navBtn = findGalleryNavButton(heroRoot);

        if (!navBtn || isGalleryNavDisabled(navBtn)) break;

        navBtn.click();

        advanced = true;

      }

      if (!advanced) break;



      await sleep(280);

      activateLazyLoadedImages(heroRoot);

      heroRoot.querySelectorAll(".swiper-slide, [class*='swiper-slide']").forEach((slide) => {

        collectSlideImages(slide, baseUrl, push);

      });



      if (out.length > before) {

        stagnant = 0;

      } else {

        stagnant += 1;

        if (stagnant >= MAX_STAGNANT) break;

      }

    }

  }



  async function collectPageGalleryUrls(doc, maxCount = 30) {

    const baseUrl = doc.defaultView?.location?.href ?? global.location?.href ?? "";

    const heroRoot = findHeroGalleryRoot(doc);

    if (!heroRoot) return { productGalleryUrls: [], heroImageUrl: undefined };



    const seen = new Set();

    const out = [];

    const push = (url) => {

      if (!url || seen.has(url) || isJunkImageUrl(url)) return;

      seen.add(url);

      out.push(url);

    };



    const ogImage = collectOgImageUrl(doc);

    if (ogImage) push(ogImage);



    const slideSelectors = [".swiper-slide-active", ".swiper-slide", "[class*='swiper-slide']"];

    const collectedSlides = new Set();

    for (const sel of slideSelectors) {

      try {

        heroRoot.querySelectorAll(sel).forEach((slide) => {

          if (collectedSlides.has(slide)) return;

          collectedSlides.add(slide);

          collectSlideImages(slide, baseUrl, push);

        });

      } catch {

        /* ignore */

      }

    }



    // 슬라이더가 가상/지연 렌더링이라 슬라이드가 1~2개만 DOM에 있는 경우를 대비해

    // 다음 버튼을 눌러가며 추가 슬라이드를 계속 수집한다.

    await advanceGalleryAndCollect(heroRoot, baseUrl, push, out);



    if (out.length === 0) {

      let count = 0;

      for (const img of heroRoot.querySelectorAll("img")) {

        if (count >= maxCount * 2) break;

        const url = resolveImageUrl(img, baseUrl);

        if (url) push(url);

        count++;

      }

    }



    const productGalleryUrls = out.slice(0, maxCount);

    return {

      productGalleryUrls,

      heroImageUrl: productGalleryUrls[0],

    };

  }



  async function capturePageContext(doc, onProgress) {

    onProgress?.(8, "대표 이미지 수집 중…");

    activateLazyLoadedImages(doc);

    const { productGalleryUrls, heroImageUrl } = await collectPageGalleryUrls(doc);

    const sourceProductTitle = extractSourceProductTitle(doc);

    const seoHashtags = extractAiSeoHashtags(doc);



    onProgress?.(12, "상품 정보 수집 중…");

    let rawHtmlText = buildPageTextForMeta(doc);



    onProgress?.(16, "상품안내 탭 펼치는 중…");

    await prepareSellingPointsView(doc);

    const sellingText = buildPageTextForMeta(doc, 8000);

    rawHtmlText = appendMetaText(rawHtmlText, sellingText);



    onProgress?.(20, "일정 탭 펼치는 중…");

    await prepareItineraryView(doc);

    const ui = global.HanatourItineraryUiPrep;
    const itineraryPanel = ui?.findItineraryTabPanel?.(doc) ?? findHtmlCaptureRoot(doc);
    if (itineraryPanel && ui?.scrollPanelToLoadLazy) {
      await ui.scrollPanelToLoadLazy(itineraryPanel);
    }

    onProgress?.(28, "이미지 로딩 중…");

    await scrollToLoadLazyContent(doc);

    activateLazyLoadedImages(doc);

    onProgress?.(34, "HTML 구조 수집 중…");

    const cleanHtmlStructure = buildCleanHtmlStructure(doc);

    onProgress?.(36, "일정 블록 추출 중…");

    let itineraryBlocks = [];
    let itineraryExtractMeta;
    const extractAsync = global.ItineraryDomExtract?.extractItineraryBlocksAsync;
    if (typeof extractAsync === "function") {
      const result = await extractAsync(doc, {
        onDayProgress: (day) => onProgress?.(36, `일정 ${day}일차 수집 중…`),
      });
      itineraryBlocks = result?.blocks ?? [];
      itineraryExtractMeta = result?.meta;
    } else {
      itineraryBlocks = global.ItineraryDomExtract?.extractItineraryBlocks?.(doc) ?? [];
    }

    onProgress?.(37, "호텔·선택관광 탭 수집 중…");

    let packageCatalog;
    const extractCatalog = global.PackageCatalogExtract?.extractPackageCatalog;
    if (typeof extractCatalog === "function") {
      try {
        packageCatalog = await extractCatalog(doc, {
          onProgress: (label) => onProgress?.(37, label),
        });
      } catch (err) {
        console.warn("[thealltour-import] package catalog extract failed:", err);
      }
    }

    onProgress?.(38, "수집 완료");

    return {
      cleanHtmlStructure,
      rawHtmlText,
      productGalleryUrls,
      heroImageUrl,
      sourceProductTitle,
      seoHashtags,
      itineraryBlocks,
      itineraryExtractMeta,
      packageCatalog,
    };

  }



  global.HtmlContextExtract = {

    sleep,

    activateLazyLoadedImages,

    minifyHtmlForAi,

    sanitizeHtmlClone,

    buildCleanHtmlStructure,

    buildBodyHtmlCaptureRoot,

    buildCombinedHtmlCaptureRoot,

    findHtmlCaptureRoot,

    buildPageTextForMeta,

    findBookingPriceRoot,

    collectPageGalleryUrls,

    extractSourceProductTitle,

    extractAiSeoHashtags,

    prepareItineraryView,

    prepareSellingPointsView,

    scrollToLoadLazyContent,

    capturePageContext,

  };

})(typeof globalThis !== "undefined" ? globalThis : window);

